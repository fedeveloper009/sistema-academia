# 🏋️ Sistema de Gestão de Academia — JavaFX + Maven

Frontend desktop completo em **JavaFX 21** com estrutura **Maven**, pronto para importar no **IntelliJ IDEA**.

---

## ✅ Pré-requisitos

| Ferramenta | Versão mínima |
|---|---|
| Java JDK | 17 (LTS) ou superior |
| Maven | 3.8+ (ou usar o Maven embutido do IntelliJ) |
| IntelliJ IDEA | 2022.1+ (Community ou Ultimate) |

---

## 🚀 Como importar no IntelliJ IDEA

### Opção 1 — Importar via "Open"
1. Abra o IntelliJ IDEA
2. Clique em **File → Open...**
3. Navegue até a pasta `sistema-academia/` e clique em **OK**
4. O IntelliJ detectará o `pom.xml` automaticamente e perguntará se deseja importar como projeto Maven → clique **Trust Project**
5. Aguarde o Maven baixar as dependências (barra de progresso no canto inferior)

### Opção 2 — Importar via "New Project from Existing Sources"
1. **File → New → Project from Existing Sources...**
2. Selecione a pasta `sistema-academia/`
3. Escolha **Import project from external model → Maven**
4. Clique **Finish**

---

## ▶️ Como executar

### Pelo painel de Run Configurations (recomendado)
Após a importação, a configuração **"Executar Academia (JavaFX)"** já estará disponível no seletor de run (canto superior direito).  
Basta clicar no botão **▶ Run** (verde).

### Pelo Maven Tool Window
1. Abra a aba **Maven** (lado direito do IntelliJ)
2. Expanda **sistema-academia → Plugins → javafx**
3. Dê duplo clique em **javafx:run**

### Pelo Terminal integrado
```bash
mvn javafx:run
```

---

## 🗂️ Estrutura do Projeto

```
sistema-academia/
├── .idea/                          ← Configurações do IntelliJ
├── .run/                           ← Run Configuration pré-configurada
├── pom.xml                         ← Dependências Maven (JavaFX 21)
└── src/main/java/
    ├── module-info.java
    └── com/academia/
        ├── MainApp.java            ← Ponto de entrada (extends Application)
        ├── model/
        │   ├── Planos.java         ← Valores dos planos
        │   ├── Funcionario.java    ← Encapsulamento com getters/setters
        │   ├── Instrutor.java      ← Herança de Funcionario
        │   └── Academia.java       ← Lógica central de negócio
        ├── view/
        │   ├── MainView.java       ← Janela principal + navegação lateral
        │   └── UIHelper.java       ← Sistema de design (cores, cards, botões)
        └── controller/
            ├── DashboardController.java      ← Visão geral com KPIs
            ├── PlanosController.java         ← Tabela de planos
            ├── FuncionariosController.java   ← Listagem + cadastro
            ├── InstrutoresController.java    ← Listagem + cadastro
            ├── FinanceiroController.java     ← Relatório financeiro
            └── VendaPlanoController.java     ← Registrar matrículas
```

---

## 📱 Telas disponíveis

| Tela | Funcionalidade |
|---|---|
| **Dashboard** | KPIs ao vivo: matrículas, funcionários, receita e lucro |
| **Planos** | Cards dos 3 planos com preços e matrículas ativas |
| **Funcionários** | Formulário de contratação + tabela de colaboradores |
| **Instrutores** | Cadastro completo (CPF, e-mail, especialidade) + listagem |
| **Relatório Financeiro** | Detalhamento de folha, gastos e receita por plano |
| **Vender Plano** | Registra nova matrícula e atualiza contadores ao vivo |

---

## 🧱 Conceitos de POO mantidos

| Conceito | Onde é aplicado |
|---|---|
| **Encapsulamento** | Atributos `private` com getters/setters em todas as classes |
| **Herança** | `Instrutor extends Funcionario` |
| **Abstração** | `Academia` centraliza as regras de negócio |
| **Composição** | `Academia` compõe `Planos`, `Funcionario` e `Instrutor` |

---

## ⚠️ Solução de problemas

**"Cannot find JavaFX runtime components"**  
→ Verifique que o JDK configurado no IntelliJ é o **17 ou superior** em *File → Project Structure → SDKs*

**Maven não baixa as dependências**  
→ No painel Maven (aba lateral), clique no ícone 🔄 **Reload All Maven Projects**

**Erro de módulo (`module-info.java`)**  
→ Certifique-se de que o projeto está configurado com **Java 17+** em *File → Project Structure → Project → SDK*
