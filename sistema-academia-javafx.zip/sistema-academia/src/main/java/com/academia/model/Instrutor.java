package com.academia.model;

public class Instrutor extends Funcionario {

    private String cpf;
    private String email;
    private String especialidade;

    public Instrutor(String nome, String especialidade, String cpf, String email,
                     int anosExperiencia, double salario) {
        super(nome, "Instrutor", anosExperiencia, salario);
        this.especialidade = especialidade;
        this.cpf = cpf;
        this.email = email;
    }

    public String getCpf()                   { return cpf; }
    public void   setCpf(String cpf)         { this.cpf = cpf; }

    public String getEmail()                 { return email; }
    public void   setEmail(String email)     { this.email = email; }

    public String getEspecialidade()                         { return especialidade; }
    public void   setEspecialidade(String especialidade)     { this.especialidade = especialidade; }

    @Override
    public String toString() {
        return getNome() + " — " + especialidade;
    }
}
