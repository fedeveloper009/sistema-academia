package com.academia.model;

public class Funcionario {

    private String nome;
    private String cargo;
    private int anosExperiencia;
    private double salario;

    public Funcionario(String nome, String cargo, int anosExperiencia, double salario) {
        this.nome = nome;
        this.cargo = cargo;
        this.anosExperiencia = anosExperiencia;
        this.salario = salario;
    }

    public String getNome()              { return nome; }
    public void   setNome(String nome)   { this.nome = nome; }

    public String getCargo()             { return cargo; }
    public void   setCargo(String cargo) { this.cargo = cargo; }

    public int getAnosExperiencia()                     { return anosExperiencia; }
    public void setAnosExperiencia(int anosExperiencia) { this.anosExperiencia = anosExperiencia; }

    public double getSalario()               { return salario; }
    public void   setSalario(double salario) { this.salario = salario; }

    @Override
    public String toString() {
        return nome + " — " + cargo;
    }
}
