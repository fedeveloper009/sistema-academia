package com.academia.model;

public class Planos {

    public static final String MAIS_BARATO = "Mais Barato";
    public static final String NORMAL = "Normal";
    public static final String PLUS_ULTRA = "Plus Ultra";

    private final double valorPlanoBarato = 59.99;
    private final double valorPlanoMedio = 89.99;
    private final double valorPlanoPlus = 119.99;

    public double getValorPlanoBarato() { return valorPlanoBarato; }
    public double getValorPlanoMedio()  { return valorPlanoMedio; }
    public double getValorPlanoPlus()   { return valorPlanoPlus; }

    public double getValorByNome(String nome) {
        return switch (nome) {
            case MAIS_BARATO -> valorPlanoBarato;
            case NORMAL      -> valorPlanoMedio;
            case PLUS_ULTRA  -> valorPlanoPlus;
            default          -> 0;
        };
    }
}
