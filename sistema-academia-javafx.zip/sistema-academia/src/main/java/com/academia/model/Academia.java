package com.academia.model;

import java.util.ArrayList;
import java.util.List;

public class Academia {

    private final String nome;
    private final List<Funcionario> funcionarios = new ArrayList<>();
    private final List<Instrutor>   instrutores  = new ArrayList<>();
    private final Planos planos = new Planos();

    // contratos por plano
    private int totalPlanoBarato = 15;
    private int totalPlanoNormal = 22;
    private int totalPlanoCaro   = 8;

    public Academia(String nome) {
        this.nome = nome;
        // dados de demonstração
        funcionarios.add(new Funcionario("Carlos Silva",   "Recepcionista", 3, 2200.00));
        funcionarios.add(new Funcionario("Ana Souza",      "Gerente",       7, 4800.00));
        funcionarios.add(new Funcionario("Pedro Lima",     "Limpeza",       1, 1500.00));
        instrutores.add(new Instrutor("Marcos Oliveira", "Musculação",  "111.222.333-44", "marcos@academia.com", 5, 3500.00));
        instrutores.add(new Instrutor("Juliana Costa",   "Yoga",        "555.666.777-88", "juliana@academia.com", 3, 3000.00));
        instrutores.add(new Instrutor("Rafael Mendes",   "Crossfit",    "999.000.111-22", "rafael@academia.com",  4, 3200.00));
    }

    // ── Getters ──────────────────────────────────────────────────────────────

    public String getNome()               { return nome; }
    public List<Funcionario> getFuncionarios() { return funcionarios; }
    public List<Instrutor>   getInstrutores()  { return instrutores; }
    public Planos getPlanos()             { return planos; }

    public int getTotalPlanoBarato() { return totalPlanoBarato; }
    public int getTotalPlanoNormal() { return totalPlanoNormal; }
    public int getTotalPlanoCaro()   { return totalPlanoCaro; }

    // ── Finanças ─────────────────────────────────────────────────────────────

    public double getGastosFuncionarios() {
        return funcionarios.stream().mapToDouble(Funcionario::getSalario).sum();
    }

    public double getGastosInstrutores() {
        return instrutores.stream().mapToDouble(Funcionario::getSalario).sum();
    }

    public double getTotalFolha() {
        return getGastosFuncionarios() + getGastosInstrutores();
    }

    public double getReceitaMensal() {
        return totalPlanoBarato * planos.getValorPlanoBarato()
             + totalPlanoNormal * planos.getValorPlanoMedio()
             + totalPlanoCaro   * planos.getValorPlanoPlus();
    }

    public double getLucroMensal() {
        return getReceitaMensal() - getTotalFolha();
    }

    // ── Operações ─────────────────────────────────────────────────────────────

    public void contratarFuncionario(Funcionario f) {
        funcionarios.add(f);
    }

    public void contratarInstrutor(Instrutor i) {
        instrutores.add(i);
    }

    public void registrarVendaPlano(String plano) {
        switch (plano) {
            case Planos.MAIS_BARATO -> totalPlanoBarato++;
            case Planos.NORMAL      -> totalPlanoNormal++;
            case Planos.PLUS_ULTRA  -> totalPlanoCaro++;
        }
    }
}
