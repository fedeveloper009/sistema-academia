package com.academia.view;

import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;

public final class UIHelper {

    public static final String COLOR_PRIMARY = "#E63946";
    public static final String COLOR_DARK    = "#1A1A2E";
    public static final String COLOR_DARKER  = "#16213E";
    public static final String COLOR_CARD    = "#0F3460";
    public static final String COLOR_TEXT    = "#EAEAEA";
    public static final String COLOR_MUTED   = "#8899AA";
    public static final String COLOR_SUCCESS = "#2EC4B6";
    public static final String COLOR_WARNING = "#FF9F1C";

    private UIHelper() {}

    /** Título de seção */
    public static Label sectionTitle(String text) {
        Label lbl = new Label(text);
        lbl.setStyle(
            "-fx-text-fill: " + COLOR_TEXT + ";" +
            "-fx-font-size: 22px;" +
            "-fx-font-weight: bold;"
        );
        return lbl;
    }

    /** Card genérico com fundo escuro e borda */
    public static VBox card(String title, String value, String subtitle, String accentColor) {
        VBox box = new VBox(6);
        box.setPadding(new Insets(18, 20, 18, 20));
        box.setStyle(
            "-fx-background-color: " + COLOR_CARD + ";" +
            "-fx-background-radius: 10;" +
            "-fx-border-color: " + accentColor + ";" +
            "-fx-border-width: 0 0 0 4;" +
            "-fx-border-radius: 10;"
        );
        box.setPrefWidth(200);

        Label titleLbl = new Label(title);
        titleLbl.setStyle("-fx-text-fill: " + COLOR_MUTED + "; -fx-font-size: 12px;");

        Label valueLbl = new Label(value);
        valueLbl.setStyle("-fx-text-fill: " + COLOR_TEXT + "; -fx-font-size: 24px; -fx-font-weight: bold;");

        Label subLbl = new Label(subtitle);
        subLbl.setStyle("-fx-text-fill: " + accentColor + "; -fx-font-size: 11px;");

        box.getChildren().addAll(titleLbl, valueLbl, subLbl);
        return box;
    }

    /** Wrapper de página com padding e título */
    public static VBox pageWrapper(String title) {
        VBox wrapper = new VBox(20);
        wrapper.setPadding(new Insets(30, 30, 30, 30));
        wrapper.setStyle("-fx-background-color: " + COLOR_DARK + ";");

        Label titleLbl = sectionTitle(title);
        Region sep = new Region();
        sep.setPrefHeight(1);
        sep.setStyle("-fx-background-color: " + COLOR_PRIMARY + "66;");

        wrapper.getChildren().addAll(titleLbl, sep);
        return wrapper;
    }

    /** Botão primário */
    public static javafx.scene.control.Button primaryButton(String text) {
        javafx.scene.control.Button btn = new javafx.scene.control.Button(text);
        btn.setStyle(
            "-fx-background-color: " + COLOR_PRIMARY + ";" +
            "-fx-text-fill: white;" +
            "-fx-font-weight: bold;" +
            "-fx-font-size: 13px;" +
            "-fx-padding: 10 24 10 24;" +
            "-fx-background-radius: 6;" +
            "-fx-cursor: hand;"
        );
        btn.setOnMouseEntered(e -> btn.setStyle(
            "-fx-background-color: #c0303c;" +
            "-fx-text-fill: white;" +
            "-fx-font-weight: bold;" +
            "-fx-font-size: 13px;" +
            "-fx-padding: 10 24 10 24;" +
            "-fx-background-radius: 6;" +
            "-fx-cursor: hand;"
        ));
        btn.setOnMouseExited(e -> btn.setStyle(
            "-fx-background-color: " + COLOR_PRIMARY + ";" +
            "-fx-text-fill: white;" +
            "-fx-font-weight: bold;" +
            "-fx-font-size: 13px;" +
            "-fx-padding: 10 24 10 24;" +
            "-fx-background-radius: 6;" +
            "-fx-cursor: hand;"
        ));
        return btn;
    }

    /** Botão secundário */
    public static javafx.scene.control.Button secondaryButton(String text) {
        javafx.scene.control.Button btn = new javafx.scene.control.Button(text);
        btn.setStyle(
            "-fx-background-color: transparent;" +
            "-fx-text-fill: " + COLOR_PRIMARY + ";" +
            "-fx-font-weight: bold;" +
            "-fx-font-size: 13px;" +
            "-fx-padding: 9 22 9 22;" +
            "-fx-background-radius: 6;" +
            "-fx-border-color: " + COLOR_PRIMARY + ";" +
            "-fx-border-radius: 6;" +
            "-fx-cursor: hand;"
        );
        return btn;
    }

    /** Label de campo de formulário */
    public static Label fieldLabel(String text) {
        Label lbl = new Label(text);
        lbl.setStyle("-fx-text-fill: " + COLOR_MUTED + "; -fx-font-size: 12px;");
        return lbl;
    }

    /** Estilo de TextField */
    public static String textFieldStyle() {
        return "-fx-background-color: " + COLOR_DARKER + ";" +
               "-fx-text-fill: " + COLOR_TEXT + ";" +
               "-fx-border-color: #334;" +
               "-fx-border-radius: 5;" +
               "-fx-background-radius: 5;" +
               "-fx-padding: 8 12 8 12;" +
               "-fx-font-size: 13px;";
    }

    /** Estilo de ComboBox */
    public static String comboStyle() {
        return "-fx-background-color: " + COLOR_DARKER + ";" +
               "-fx-text-fill: " + COLOR_TEXT + ";" +
               "-fx-border-color: #334;" +
               "-fx-border-radius: 5;" +
               "-fx-background-radius: 5;";
    }

    /** Card de plano */
    public static VBox planoCard(String nome, double valor, int matriculas, String color) {
        VBox card = new VBox(10);
        card.setPadding(new Insets(20));
        card.setAlignment(Pos.CENTER);
        card.setPrefWidth(230);
        card.setStyle(
            "-fx-background-color: " + COLOR_CARD + ";" +
            "-fx-background-radius: 12;" +
            "-fx-border-color: " + color + ";" +
            "-fx-border-width: 2;" +
            "-fx-border-radius: 12;"
        );

        Label nameLbl = new Label(nome);
        nameLbl.setStyle("-fx-text-fill: " + color + "; -fx-font-size: 14px; -fx-font-weight: bold;");

        Label priceLbl = new Label(String.format("R$ %.2f", valor));
        priceLbl.setStyle("-fx-text-fill: " + COLOR_TEXT + "; -fx-font-size: 28px; -fx-font-weight: bold;");

        Label perMonth = new Label("/mês");
        perMonth.setStyle("-fx-text-fill: " + COLOR_MUTED + "; -fx-font-size: 11px;");

        Region sep = new Region();
        sep.setPrefHeight(1);
        sep.setStyle("-fx-background-color: " + color + "44;");
        sep.setMaxWidth(Double.MAX_VALUE);

        Label matLbl = new Label("🎫 " + matriculas + " matrículas ativas");
        matLbl.setStyle("-fx-text-fill: " + COLOR_MUTED + "; -fx-font-size: 12px;");

        card.getChildren().addAll(nameLbl, priceLbl, perMonth, sep, matLbl);
        return card;
    }
}
