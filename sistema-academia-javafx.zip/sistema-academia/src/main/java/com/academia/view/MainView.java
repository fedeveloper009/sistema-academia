package com.academia.view;

import com.academia.MainApp;
import com.academia.controller.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class MainView {

    private final Stage stage;
    private BorderPane root;
    private VBox sidebar;

    // Cor principal da academia
    private static final String COLOR_PRIMARY   = "#E63946";
    private static final String COLOR_DARK      = "#1A1A2E";
    private static final String COLOR_DARKER    = "#16213E";
    private static final String COLOR_ACCENT    = "#0F3460";
    private static final String COLOR_TEXT      = "#EAEAEA";
    private static final String COLOR_SIDEBAR_BTN_HOVER = "#E63946";

    public MainView(Stage stage) {
        this.stage = stage;
    }

    public void show() {
        root = new BorderPane();
        root.setStyle("-fx-background-color: " + COLOR_DARK + ";");

        // ── Sidebar ─────────────────────────────────────────────────────────
        sidebar = buildSidebar();
        root.setLeft(sidebar);

        // ── Conteúdo inicial (Dashboard) ─────────────────────────────────────
        showDashboard();

        // ── Header ───────────────────────────────────────────────────────────
        HBox header = buildHeader();
        root.setTop(header);

        Scene scene = new Scene(root, 1100, 680);
        stage.setTitle("🏋️ Sistema de Gestão de Academia — " + MainApp.academia.getNome());
        stage.setScene(scene);
        stage.setMinWidth(900);
        stage.setMinHeight(600);
        stage.show();
    }

    // ── Header ────────────────────────────────────────────────────────────────

    private HBox buildHeader() {
        HBox header = new HBox();
        header.setPadding(new Insets(14, 24, 14, 24));
        header.setAlignment(Pos.CENTER_LEFT);
        header.setStyle("-fx-background-color: " + COLOR_DARKER + "; -fx-border-color: " + COLOR_PRIMARY + "; -fx-border-width: 0 0 2 0;");

        Label icon  = new Label("🏋️");
        icon.setStyle("-fx-font-size: 22px;");

        Label title = new Label("  " + MainApp.academia.getNome());
        title.setStyle("-fx-font-size: 20px; -fx-font-weight: bold; -fx-text-fill: " + COLOR_TEXT + ";");

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        Label version = new Label("v1.0.0  ");
        version.setStyle("-fx-text-fill: #888; -fx-font-size: 11px;");

        header.getChildren().addAll(icon, title, spacer, version);
        return header;
    }

    // ── Sidebar ───────────────────────────────────────────────────────────────

    private VBox buildSidebar() {
        VBox box = new VBox(6);
        box.setPadding(new Insets(20, 0, 20, 0));
        box.setPrefWidth(210);
        box.setStyle("-fx-background-color: " + COLOR_DARKER + ";");

        Label menuLabel = new Label("  MENU");
        menuLabel.setStyle("-fx-text-fill: #666; -fx-font-size: 11px; -fx-font-weight: bold; -fx-padding: 0 0 8 16;");

        Button[] btns = {
            navBtn("📊  Dashboard",       () -> showDashboard()),
            navBtn("📋  Planos",           () -> showContent(new PlanosController().getView())),
            navBtn("👤  Funcionários",     () -> showContent(new FuncionariosController().getView())),
            navBtn("🏃  Instrutores",      () -> showContent(new InstrutoresController().getView())),
            navBtn("💰  Relatório Financeiro", () -> showContent(new FinanceiroController().getView())),
            navBtn("🎟️  Vender Plano",    () -> showContent(new VendaPlanoController().getView())),
        };

        box.getChildren().add(menuLabel);
        for (Button b : btns) box.getChildren().add(b);

        return box;
    }

    private Button navBtn(String text, Runnable action) {
        Button btn = new Button(text);
        btn.setMaxWidth(Double.MAX_VALUE);
        btn.setAlignment(Pos.CENTER_LEFT);
        btn.setPadding(new Insets(12, 16, 12, 20));
        btn.setStyle(
            "-fx-background-color: transparent;" +
            "-fx-text-fill: " + COLOR_TEXT + ";" +
            "-fx-font-size: 13px;" +
            "-fx-cursor: hand;" +
            "-fx-border-radius: 0;"
        );
        btn.setOnMouseEntered(e -> btn.setStyle(
            "-fx-background-color: " + COLOR_PRIMARY + "33;" +
            "-fx-text-fill: " + COLOR_TEXT + ";" +
            "-fx-font-size: 13px;" +
            "-fx-cursor: hand;" +
            "-fx-border-color: " + COLOR_PRIMARY + ";" +
            "-fx-border-width: 0 0 0 3;"
        ));
        btn.setOnMouseExited(e -> btn.setStyle(
            "-fx-background-color: transparent;" +
            "-fx-text-fill: " + COLOR_TEXT + ";" +
            "-fx-font-size: 13px;" +
            "-fx-cursor: hand;"
        ));
        btn.setOnAction(e -> action.run());
        return btn;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private void showDashboard() {
        showContent(new DashboardController().getView());
    }

    private void showContent(javafx.scene.Node node) {
        ScrollPane scroll = new ScrollPane(node);
        scroll.setFitToWidth(true);
        scroll.setStyle("-fx-background: " + COLOR_DARK + "; -fx-background-color: " + COLOR_DARK + ";");
        root.setCenter(scroll);
    }
}
