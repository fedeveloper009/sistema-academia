package com.academia;

import com.academia.model.Academia;
import com.academia.view.MainView;
import javafx.application.Application;
import javafx.stage.Stage;

public class MainApp extends Application {

    // Instância global compartilhada entre controllers
    public static final Academia academia = new Academia("FitLife Academia");

    @Override
    public void start(Stage primaryStage) {
        MainView mainView = new MainView(primaryStage);
        mainView.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
