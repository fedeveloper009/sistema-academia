package com.academia.controller;

import com.academia.MainApp;
import com.academia.model.Academia;
import com.academia.model.Planos;
import com.academia.view.UIHelper;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.*;

public class PlanosController {

    private final Academia academia = MainApp.academia;

    public Node getView() {
        VBox wrapper = UIHelper.pageWrapper("📋  Tabela de Planos Disponíveis");

        // Cards dos planos
        HBox cardsRow = new HBox(24);
        cardsRow.setAlignment(Pos.CENTER_LEFT);
        cardsRow.getChildren().addAll(
            UIHelper.planoCard("🥉 Mais Barato",
                academia.getPlanos().getValorPlanoBarato(),
                academia.getTotalPlanoBarato(),
                UIHelper.COLOR_SUCCESS),
            UIHelper.planoCard("🥈 Normal",
                academia.getPlanos().getValorPlanoMedio(),
                academia.getTotalPlanoNormal(),
                UIHelper.COLOR_WARNING),
            UIHelper.planoCard("🥇 Plus Ultra",
                academia.getPlanos().getValorPlanoPlus(),
                academia.getTotalPlanoCaro(),
                "#AA88FF")
        );

        // Detalhes adicionais
        Label detailTitle = new Label("Detalhes dos Planos");
        detailTitle.setStyle("-fx-text-fill: " + UIHelper.COLOR_TEXT + "; -fx-font-size: 16px; -fx-font-weight: bold;");

        VBox detailBox = new VBox(0);
        detailBox.setStyle(
            "-fx-background-color: " + UIHelper.COLOR_CARD + ";" +
            "-fx-background-radius: 10;"
        );

        String[][] dados = {
            {"Plano",        "Preço Mensal", "Matrículas", "Receita Mensal"},
            {"Mais Barato",  "R$ 59,99",     String.valueOf(academia.getTotalPlanoBarato()),
                String.format("R$ %.2f", academia.getTotalPlanoBarato() * academia.getPlanos().getValorPlanoBarato())},
            {"Normal",       "R$ 89,99",     String.valueOf(academia.getTotalPlanoNormal()),
                String.format("R$ %.2f", academia.getTotalPlanoNormal() * academia.getPlanos().getValorPlanoMedio())},
            {"Plus Ultra",   "R$ 119,99",    String.valueOf(academia.getTotalPlanoCaro()),
                String.format("R$ %.2f", academia.getTotalPlanoCaro() * academia.getPlanos().getValorPlanoPlus())},
        };

        for (int i = 0; i < dados.length; i++) {
            HBox row = tableRow(dados[i], i == 0);
            detailBox.getChildren().add(row);
        }

        // Total
        HBox totalRow = new HBox();
        totalRow.setPadding(new Insets(12, 16, 12, 16));
        totalRow.setAlignment(Pos.CENTER_RIGHT);
        totalRow.setStyle("-fx-background-color: " + UIHelper.COLOR_PRIMARY + "22; -fx-background-radius: 0 0 10 10;");
        Label totalLbl = new Label(String.format("Receita Total Estimada:   R$ %.2f", academia.getReceitaMensal()));
        totalLbl.setStyle("-fx-text-fill: " + UIHelper.COLOR_PRIMARY + "; -fx-font-size: 14px; -fx-font-weight: bold;");
        totalRow.getChildren().add(totalLbl);
        detailBox.getChildren().add(totalRow);

        wrapper.getChildren().addAll(cardsRow, detailTitle, detailBox);
        return wrapper;
    }

    private HBox tableRow(String[] cells, boolean isHeader) {
        HBox row = new HBox();
        row.setPadding(new Insets(12, 16, 12, 16));
        if (isHeader) {
            row.setStyle("-fx-background-color: " + UIHelper.COLOR_DARKER + "; -fx-background-radius: 10 10 0 0;");
        } else {
            row.setStyle("-fx-border-color: " + UIHelper.COLOR_DARKER + "; -fx-border-width: 1 0 0 0;");
        }
        for (String cell : cells) {
            Label lbl = new Label(cell);
            lbl.setPrefWidth(200);
            if (isHeader) {
                lbl.setStyle("-fx-text-fill: " + UIHelper.COLOR_MUTED + "; -fx-font-size: 12px; -fx-font-weight: bold;");
            } else {
                lbl.setStyle("-fx-text-fill: " + UIHelper.COLOR_TEXT + "; -fx-font-size: 13px;");
            }
            row.getChildren().add(lbl);
        }
        return row;
    }
}
