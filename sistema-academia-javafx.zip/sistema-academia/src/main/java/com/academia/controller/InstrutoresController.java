package com.academia.controller;

import com.academia.MainApp;
import com.academia.model.Academia;
import com.academia.model.Instrutor;
import com.academia.view.UIHelper;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.*;

public class InstrutoresController {

    private final Academia academia = MainApp.academia;
    private VBox listBox;

    public Node getView() {
        VBox wrapper = UIHelper.pageWrapper("🏃  Instrutores");

        // ── Formulário ─────────────────────────────────────────────────────
        Label formTitle = new Label("Cadastrar Novo Instrutor");
        formTitle.setStyle("-fx-text-fill: " + UIHelper.COLOR_TEXT + "; -fx-font-size: 15px; -fx-font-weight: bold;");

        GridPane form = new GridPane();
        form.setHgap(16);
        form.setVgap(10);
        form.setPadding(new Insets(16));
        form.setStyle("-fx-background-color: " + UIHelper.COLOR_CARD + "; -fx-background-radius: 10;");

        TextField nomeField  = stf("Nome completo");
        TextField espField   = stf("Especialidade (ex: Musculação)");
        TextField cpfField   = stf("CPF");
        TextField emailField = stf("E-mail");
        TextField anosField  = stf("Anos de experiência");
        TextField salField   = stf("Salário (ex: 3200.00)");

        ColumnConstraints ccLabel = new ColumnConstraints(130);
        ColumnConstraints ccField = new ColumnConstraints();
        ccField.setHgrow(Priority.ALWAYS);
        form.getColumnConstraints().addAll(ccLabel, ccField, ccLabel, ccField);

        form.add(UIHelper.fieldLabel("Nome"),          0, 0); form.add(nomeField,  1, 0);
        form.add(UIHelper.fieldLabel("Especialidade"), 2, 0); form.add(espField,   3, 0);
        form.add(UIHelper.fieldLabel("CPF"),           0, 1); form.add(cpfField,   1, 1);
        form.add(UIHelper.fieldLabel("E-mail"),        2, 1); form.add(emailField, 3, 1);
        form.add(UIHelper.fieldLabel("Experiência"),   0, 2); form.add(anosField,  1, 2);
        form.add(UIHelper.fieldLabel("Salário (R$)"),  2, 2); form.add(salField,   3, 2);

        Label feedbackLbl = new Label("");
        feedbackLbl.setStyle("-fx-text-fill: " + UIHelper.COLOR_SUCCESS + "; -fx-font-size: 12px;");

        Button btn = UIHelper.primaryButton("➕  Cadastrar Instrutor");
        btn.setOnAction(e -> {
            try {
                String nome  = nomeField.getText().trim();
                String esp   = espField.getText().trim();
                String cpf   = cpfField.getText().trim();
                String email = emailField.getText().trim();
                int anos     = Integer.parseInt(anosField.getText().trim());
                double sal   = Double.parseDouble(salField.getText().trim());

                if (nome.isEmpty() || esp.isEmpty()) throw new IllegalArgumentException();

                academia.contratarInstrutor(new Instrutor(nome, esp, cpf, email, anos, sal));
                nomeField.clear(); espField.clear(); cpfField.clear();
                emailField.clear(); anosField.clear(); salField.clear();
                feedbackLbl.setStyle("-fx-text-fill: " + UIHelper.COLOR_SUCCESS + "; -fx-font-size: 12px;");
                feedbackLbl.setText("✅ Instrutor cadastrado com sucesso!");
                refreshList();
            } catch (Exception ex) {
                feedbackLbl.setStyle("-fx-text-fill: " + UIHelper.COLOR_PRIMARY + "; -fx-font-size: 12px;");
                feedbackLbl.setText("⚠️ Preencha todos os campos corretamente.");
            }
        });

        HBox btnRow = new HBox(12, btn, feedbackLbl);
        btnRow.setAlignment(Pos.CENTER_LEFT);

        // ── Lista ──────────────────────────────────────────────────────────
        Label listTitle = new Label("Instrutores Cadastrados");
        listTitle.setStyle("-fx-text-fill: " + UIHelper.COLOR_TEXT + "; -fx-font-size: 15px; -fx-font-weight: bold;");

        listBox = new VBox(8);
        refreshList();

        wrapper.getChildren().addAll(formTitle, form, btnRow, listTitle, listBox);
        return wrapper;
    }

    private void refreshList() {
        listBox.getChildren().clear();
        listBox.getChildren().add(header());
        for (Instrutor i : academia.getInstrutores()) {
            listBox.getChildren().add(row(i));
        }
    }

    private HBox header() {
        HBox h = new HBox();
        h.setPadding(new Insets(8, 14, 8, 14));
        h.setStyle("-fx-background-color: " + UIHelper.COLOR_DARKER + "; -fx-background-radius: 8 8 0 0;");
        for (String t : new String[]{"Nome", "Especialidade", "E-mail", "Salário"}) {
            Label l = new Label(t);
            l.setPrefWidth(200);
            l.setStyle("-fx-text-fill: " + UIHelper.COLOR_MUTED + "; -fx-font-size: 12px; -fx-font-weight: bold;");
            h.getChildren().add(l);
        }
        return h;
    }

    private HBox row(Instrutor i) {
        HBox r = new HBox();
        r.setPadding(new Insets(10, 14, 10, 14));
        r.setAlignment(Pos.CENTER_LEFT);
        r.setStyle(
            "-fx-background-color: " + UIHelper.COLOR_CARD + ";" +
            "-fx-border-color: " + UIHelper.COLOR_DARKER + ";" +
            "-fx-border-width: 0 0 1 0;"
        );

        Label salLbl = cell(String.format("R$ %.2f", i.getSalario()));
        salLbl.setStyle("-fx-text-fill: " + UIHelper.COLOR_WARNING + "; -fx-font-size: 13px;");

        r.getChildren().addAll(cell(i.getNome()), cell(i.getEspecialidade()), cell(i.getEmail()), salLbl);
        return r;
    }

    private Label cell(String t) {
        Label l = new Label(t);
        l.setPrefWidth(200);
        l.setStyle("-fx-text-fill: " + UIHelper.COLOR_TEXT + "; -fx-font-size: 13px;");
        return l;
    }

    private TextField stf(String prompt) {
        TextField tf = new TextField();
        tf.setPromptText(prompt);
        tf.setStyle(UIHelper.textFieldStyle());
        tf.setPrefWidth(200);
        return tf;
    }
}
