package com.academia.controller;

import com.academia.MainApp;
import com.academia.model.Academia;
import com.academia.model.Funcionario;
import com.academia.view.UIHelper;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.*;

public class FuncionariosController {

    private final Academia academia = MainApp.academia;
    private VBox listBox;

    public Node getView() {
        VBox wrapper = UIHelper.pageWrapper("👤  Funcionários");

        // ── Formulário de cadastro ─────────────────────────────────────────
        Label formTitle = new Label("Contratar Novo Funcionário");
        formTitle.setStyle("-fx-text-fill: " + UIHelper.COLOR_TEXT + "; -fx-font-size: 15px; -fx-font-weight: bold;");

        GridPane form = new GridPane();
        form.setHgap(16);
        form.setVgap(10);
        form.setPadding(new Insets(16));
        form.setStyle("-fx-background-color: " + UIHelper.COLOR_CARD + "; -fx-background-radius: 10;");

        TextField nomeField  = styledField("Nome completo");
        TextField cargoField = styledField("Cargo");
        TextField anosField  = styledField("Anos de experiência");
        TextField salField   = styledField("Salário (ex: 2500.00)");

        form.add(UIHelper.fieldLabel("Nome"),                0, 0); form.add(nomeField,  1, 0);
        form.add(UIHelper.fieldLabel("Cargo"),               2, 0); form.add(cargoField, 3, 0);
        form.add(UIHelper.fieldLabel("Anos de experiência"), 0, 1); form.add(anosField,  1, 1);
        form.add(UIHelper.fieldLabel("Salário (R$)"),        2, 1); form.add(salField,   3, 1);

        ColumnConstraints cc = new ColumnConstraints();
        cc.setHgrow(Priority.ALWAYS);
        form.getColumnConstraints().addAll(new ColumnConstraints(120), cc, new ColumnConstraints(140), cc);

        Label feedbackLbl = new Label("");
        feedbackLbl.setStyle("-fx-text-fill: " + UIHelper.COLOR_SUCCESS + "; -fx-font-size: 12px;");

        Button btnContratar = UIHelper.primaryButton("➕  Contratar Funcionário");
        btnContratar.setOnAction(e -> {
            try {
                String nome  = nomeField.getText().trim();
                String cargo = cargoField.getText().trim();
                int anos     = Integer.parseInt(anosField.getText().trim());
                double sal   = Double.parseDouble(salField.getText().trim());

                if (nome.isEmpty() || cargo.isEmpty()) throw new IllegalArgumentException();

                academia.contratarFuncionario(new Funcionario(nome, cargo, anos, sal));
                nomeField.clear(); cargoField.clear(); anosField.clear(); salField.clear();
                feedbackLbl.setText("✅ Funcionário contratado com sucesso!");
                refreshList();
            } catch (Exception ex) {
                feedbackLbl.setStyle("-fx-text-fill: " + UIHelper.COLOR_PRIMARY + "; -fx-font-size: 12px;");
                feedbackLbl.setText("⚠️ Preencha todos os campos corretamente.");
            }
        });

        HBox btnRow = new HBox(12, btnContratar, feedbackLbl);
        btnRow.setAlignment(Pos.CENTER_LEFT);

        // ── Lista de funcionários ──────────────────────────────────────────
        Label listTitle = new Label("Funcionários Cadastrados");
        listTitle.setStyle("-fx-text-fill: " + UIHelper.COLOR_TEXT + "; -fx-font-size: 15px; -fx-font-weight: bold;");

        listBox = new VBox(8);
        refreshList();

        wrapper.getChildren().addAll(formTitle, form, btnRow, listTitle, listBox);
        return wrapper;
    }

    private void refreshList() {
        listBox.getChildren().clear();
        // cabeçalho
        listBox.getChildren().add(tableHeader());
        for (Funcionario f : academia.getFuncionarios()) {
            listBox.getChildren().add(tableRow(f));
        }
    }

    private HBox tableHeader() {
        HBox row = new HBox();
        row.setPadding(new Insets(8, 14, 8, 14));
        row.setStyle("-fx-background-color: " + UIHelper.COLOR_DARKER + "; -fx-background-radius: 8 8 0 0;");
        for (String h : new String[]{"Nome", "Cargo", "Exp.", "Salário"}) {
            Label l = new Label(h);
            l.setPrefWidth(200);
            l.setStyle("-fx-text-fill: " + UIHelper.COLOR_MUTED + "; -fx-font-size: 12px; -fx-font-weight: bold;");
            row.getChildren().add(l);
        }
        return row;
    }

    private HBox tableRow(Funcionario f) {
        HBox row = new HBox();
        row.setPadding(new Insets(10, 14, 10, 14));
        row.setAlignment(Pos.CENTER_LEFT);
        row.setStyle(
            "-fx-background-color: " + UIHelper.COLOR_CARD + ";" +
            "-fx-border-color: " + UIHelper.COLOR_DARKER + ";" +
            "-fx-border-width: 0 0 1 0;"
        );
        Label nome  = cell(f.getNome());
        Label cargo = cell(f.getCargo());
        Label anos  = cell(f.getAnosExperiencia() + " anos");
        Label sal   = cell(String.format("R$ %.2f", f.getSalario()));
        sal.setStyle("-fx-text-fill: " + UIHelper.COLOR_SUCCESS + "; -fx-font-size: 13px;");
        row.getChildren().addAll(nome, cargo, anos, sal);
        return row;
    }

    private Label cell(String text) {
        Label l = new Label(text);
        l.setPrefWidth(200);
        l.setStyle("-fx-text-fill: " + UIHelper.COLOR_TEXT + "; -fx-font-size: 13px;");
        return l;
    }

    private TextField styledField(String prompt) {
        TextField tf = new TextField();
        tf.setPromptText(prompt);
        tf.setStyle(UIHelper.textFieldStyle());
        tf.setPrefWidth(200);
        return tf;
    }
}
