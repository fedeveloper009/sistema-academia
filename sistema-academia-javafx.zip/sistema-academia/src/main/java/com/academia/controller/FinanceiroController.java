package com.academia.controller;

import com.academia.MainApp;
import com.academia.model.Academia;
import com.academia.view.UIHelper;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.*;

public class FinanceiroController {

    private final Academia academia = MainApp.academia;

    public Node getView() {
        VBox wrapper = UIHelper.pageWrapper("💰  Relatório Financeiro");

        // ── KPI Cards ──────────────────────────────────────────────────────
        HBox kpis = new HBox(16);
        kpis.setAlignment(Pos.CENTER_LEFT);

        kpis.getChildren().addAll(
            UIHelper.card("Gastos c/ Funcionários",
                String.format("R$ %.2f", academia.getGastosFuncionarios()),
                "folha geral", UIHelper.COLOR_WARNING),
            UIHelper.card("Gastos c/ Instrutores",
                String.format("R$ %.2f", academia.getGastosInstrutores()),
                "folha instrutores", UIHelper.COLOR_WARNING),
            UIHelper.card("Total Folha",
                String.format("R$ %.2f", academia.getTotalFolha()),
                "custo total mensal", UIHelper.COLOR_PRIMARY),
            UIHelper.card("Receita Mensal",
                String.format("R$ %.2f", academia.getReceitaMensal()),
                "planos contratados", UIHelper.COLOR_SUCCESS),
            UIHelper.card("Lucro Estimado",
                String.format("R$ %.2f", academia.getLucroMensal()),
                academia.getLucroMensal() >= 0 ? "▲ positivo" : "▼ negativo",
                academia.getLucroMensal() >= 0 ? UIHelper.COLOR_SUCCESS : UIHelper.COLOR_PRIMARY)
        );

        // ── Detalhamento por funcionário ───────────────────────────────────
        Label funcTitle = new Label("Detalhamento — Funcionários");
        funcTitle.setStyle("-fx-text-fill: " + UIHelper.COLOR_TEXT + "; -fx-font-size: 15px; -fx-font-weight: bold;");

        VBox funcTable = buildTable(
            new String[]{"Nome", "Cargo", "Salário"},
            academia.getFuncionarios().stream()
                .map(f -> new String[]{f.getNome(), f.getCargo(), String.format("R$ %.2f", f.getSalario())})
                .toArray(String[][]::new)
        );

        Label instTitle = new Label("Detalhamento — Instrutores");
        instTitle.setStyle("-fx-text-fill: " + UIHelper.COLOR_TEXT + "; -fx-font-size: 15px; -fx-font-weight: bold;");

        VBox instTable = buildTable(
            new String[]{"Nome", "Especialidade", "Salário"},
            academia.getInstrutores().stream()
                .map(i -> new String[]{i.getNome(), i.getEspecialidade(), String.format("R$ %.2f", i.getSalario())})
                .toArray(String[][]::new)
        );

        // ── Receita por plano ──────────────────────────────────────────────
        Label recTitle = new Label("Receita por Plano");
        recTitle.setStyle("-fx-text-fill: " + UIHelper.COLOR_TEXT + "; -fx-font-size: 15px; -fx-font-weight: bold;");

        VBox recTable = buildTable(
            new String[]{"Plano", "Matrículas", "Valor Unit.", "Receita"},
            new String[][]{
                {"Mais Barato", String.valueOf(academia.getTotalPlanoBarato()), "R$ 59,99",
                    String.format("R$ %.2f", academia.getTotalPlanoBarato() * academia.getPlanos().getValorPlanoBarato())},
                {"Normal", String.valueOf(academia.getTotalPlanoNormal()), "R$ 89,99",
                    String.format("R$ %.2f", academia.getTotalPlanoNormal() * academia.getPlanos().getValorPlanoMedio())},
                {"Plus Ultra", String.valueOf(academia.getTotalPlanoCaro()), "R$ 119,99",
                    String.format("R$ %.2f", academia.getTotalPlanoCaro() * academia.getPlanos().getValorPlanoPlus())},
            }
        );

        wrapper.getChildren().addAll(kpis, funcTitle, funcTable, instTitle, instTable, recTitle, recTable);
        return wrapper;
    }

    private VBox buildTable(String[] headers, String[][] rows) {
        VBox table = new VBox(0);
        table.setStyle("-fx-background-color: " + UIHelper.COLOR_CARD + "; -fx-background-radius: 10;");

        // header
        HBox hRow = new HBox();
        hRow.setPadding(new Insets(10, 14, 10, 14));
        hRow.setStyle("-fx-background-color: " + UIHelper.COLOR_DARKER + "; -fx-background-radius: 10 10 0 0;");
        for (String h : headers) {
            Label l = new Label(h);
            l.setPrefWidth(220);
            l.setStyle("-fx-text-fill: " + UIHelper.COLOR_MUTED + "; -fx-font-size: 12px; -fx-font-weight: bold;");
            hRow.getChildren().add(l);
        }
        table.getChildren().add(hRow);

        for (String[] row : rows) {
            HBox r = new HBox();
            r.setPadding(new Insets(10, 14, 10, 14));
            r.setStyle("-fx-border-color: " + UIHelper.COLOR_DARKER + "; -fx-border-width: 1 0 0 0;");
            for (int i = 0; i < row.length; i++) {
                Label l = new Label(row[i]);
                l.setPrefWidth(220);
                boolean isLast = (i == row.length - 1);
                l.setStyle("-fx-text-fill: " + (isLast ? UIHelper.COLOR_SUCCESS : UIHelper.COLOR_TEXT)
                    + "; -fx-font-size: 13px;");
                r.getChildren().add(l);
            }
            table.getChildren().add(r);
        }
        return table;
    }
}
