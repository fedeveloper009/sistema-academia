package com.academia.controller;

import com.academia.MainApp;
import com.academia.model.Academia;
import com.academia.view.UIHelper;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.Label;
import javafx.scene.layout.*;

public class DashboardController {

    private final Academia academia = MainApp.academia;

    public Node getView() {
        VBox wrapper = UIHelper.pageWrapper("📊  Dashboard — Visão Geral");

        // ── KPI Cards ──────────────────────────────────────────────────────
        HBox kpis = new HBox(16);
        kpis.setAlignment(Pos.CENTER_LEFT);

        int totalMatriculas = academia.getTotalPlanoBarato()
                            + academia.getTotalPlanoNormal()
                            + academia.getTotalPlanoCaro();

        kpis.getChildren().addAll(
            UIHelper.card("Total de Matrículas",
                String.valueOf(totalMatriculas), "alunos ativos", UIHelper.COLOR_PRIMARY),
            UIHelper.card("Funcionários",
                String.valueOf(academia.getFuncionarios().size()), "colaboradores", UIHelper.COLOR_SUCCESS),
            UIHelper.card("Instrutores",
                String.valueOf(academia.getInstrutores().size()), "profissionais", UIHelper.COLOR_WARNING),
            UIHelper.card("Receita Mensal",
                String.format("R$ %.0f", academia.getReceitaMensal()), "estimada", "#AA88FF"),
            UIHelper.card("Folha de Pagamento",
                String.format("R$ %.0f", academia.getTotalFolha()), "total mensal", UIHelper.COLOR_MUTED)
        );

        // ── Lucro destaque ─────────────────────────────────────────────────
        double lucro = academia.getLucroMensal();
        String lucroColor = lucro >= 0 ? UIHelper.COLOR_SUCCESS : UIHelper.COLOR_PRIMARY;

        HBox lucroBox = new HBox(10);
        lucroBox.setAlignment(Pos.CENTER_LEFT);
        lucroBox.setPadding(new Insets(16, 20, 16, 20));
        lucroBox.setStyle(
            "-fx-background-color: " + UIHelper.COLOR_CARD + ";" +
            "-fx-background-radius: 10;" +
            "-fx-border-color: " + lucroColor + ";" +
            "-fx-border-width: 2;" +
            "-fx-border-radius: 10;"
        );
        Label lucroTitle = new Label("💵  Lucro Líquido Estimado do Mês:");
        lucroTitle.setStyle("-fx-text-fill: " + UIHelper.COLOR_MUTED + "; -fx-font-size: 14px;");
        Label lucroVal = new Label(String.format("R$ %.2f", lucro));
        lucroVal.setStyle("-fx-text-fill: " + lucroColor + "; -fx-font-size: 22px; -fx-font-weight: bold;");
        lucroBox.getChildren().addAll(lucroTitle, lucroVal);

        // ── Planos resumo ──────────────────────────────────────────────────
        Label planosTitle = new Label("Distribuição de Planos");
        planosTitle.setStyle("-fx-text-fill: " + UIHelper.COLOR_TEXT + "; -fx-font-size: 15px; -fx-font-weight: bold;");

        HBox planosRow = new HBox(16);
        planosRow.setAlignment(Pos.CENTER_LEFT);
        planosRow.getChildren().addAll(
            planoMini("Mais Barato", academia.getTotalPlanoBarato(), UIHelper.COLOR_SUCCESS),
            planoMini("Normal",      academia.getTotalPlanoNormal(), UIHelper.COLOR_WARNING),
            planoMini("Plus Ultra",  academia.getTotalPlanoCaro(),   "#AA88FF")
        );

        // ── Funcionários resumo ────────────────────────────────────────────
        Label funcTitle = new Label("Equipe Recente");
        funcTitle.setStyle("-fx-text-fill: " + UIHelper.COLOR_TEXT + "; -fx-font-size: 15px; -fx-font-weight: bold;");

        VBox funcList = new VBox(8);
        academia.getFuncionarios().stream().limit(5).forEach(f -> {
            HBox row = new HBox(12);
            row.setPadding(new Insets(10, 14, 10, 14));
            row.setAlignment(Pos.CENTER_LEFT);
            row.setStyle("-fx-background-color: " + UIHelper.COLOR_CARD + "; -fx-background-radius: 8;");
            Label avatar = new Label("👤");
            Label nome   = new Label(f.getNome());
            nome.setStyle("-fx-text-fill: " + UIHelper.COLOR_TEXT + "; -fx-font-size: 13px; -fx-font-weight: bold;");
            Label cargo  = new Label("  •  " + f.getCargo());
            cargo.setStyle("-fx-text-fill: " + UIHelper.COLOR_MUTED + "; -fx-font-size: 12px;");
            Region sp = new Region(); HBox.setHgrow(sp, Priority.ALWAYS);
            Label sal = new Label(String.format("R$ %.2f", f.getSalario()));
            sal.setStyle("-fx-text-fill: " + UIHelper.COLOR_SUCCESS + "; -fx-font-size: 13px;");
            row.getChildren().addAll(avatar, nome, cargo, sp, sal);
            funcList.getChildren().add(row);
        });

        wrapper.getChildren().addAll(kpis, lucroBox, planosTitle, planosRow, funcTitle, funcList);
        return wrapper;
    }

    private VBox planoMini(String nome, int qtd, String color) {
        VBox box = new VBox(4);
        box.setPadding(new Insets(14, 20, 14, 20));
        box.setAlignment(Pos.CENTER);
        box.setPrefWidth(150);
        box.setStyle(
            "-fx-background-color: " + UIHelper.COLOR_CARD + ";" +
            "-fx-background-radius: 8;" +
            "-fx-border-color: " + color + "44;" +
            "-fx-border-radius: 8;"
        );
        Label n = new Label(nome);  n.setStyle("-fx-text-fill: " + UIHelper.COLOR_MUTED + "; -fx-font-size: 11px;");
        Label q = new Label(String.valueOf(qtd)); q.setStyle("-fx-text-fill: " + color + "; -fx-font-size: 26px; -fx-font-weight: bold;");
        Label l = new Label("matrículas"); l.setStyle("-fx-text-fill: " + UIHelper.COLOR_MUTED + "; -fx-font-size: 10px;");
        box.getChildren().addAll(n, q, l);
        return box;
    }
}
