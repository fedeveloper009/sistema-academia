package com.academia.controller;

import com.academia.MainApp;
import com.academia.model.Academia;
import com.academia.model.Planos;
import com.academia.view.UIHelper;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.*;

public class VendaPlanoController {

    private final Academia academia = MainApp.academia;

    // Labels de contadores que precisam ser atualizadas
    private Label cntBarato, cntNormal, cntPlus;

    public Node getView() {
        VBox wrapper = UIHelper.pageWrapper("🎟️  Registrar Venda de Plano");

        // ── Contadores atuais ──────────────────────────────────────────────
        Label currentTitle = new Label("Matrículas Ativas");
        currentTitle.setStyle("-fx-text-fill: " + UIHelper.COLOR_TEXT + "; -fx-font-size: 15px; -fx-font-weight: bold;");

        cntBarato = counterLabel(String.valueOf(academia.getTotalPlanoBarato()));
        cntNormal  = counterLabel(String.valueOf(academia.getTotalPlanoNormal()));
        cntPlus    = counterLabel(String.valueOf(academia.getTotalPlanoCaro()));

        HBox counters = new HBox(20);
        counters.setAlignment(Pos.CENTER_LEFT);
        counters.getChildren().addAll(
            counterCard("🥉 Mais Barato", cntBarato, UIHelper.COLOR_SUCCESS),
            counterCard("🥈 Normal",      cntNormal,  UIHelper.COLOR_WARNING),
            counterCard("🥇 Plus Ultra",  cntPlus,    "#AA88FF")
        );

        // ── Formulário de venda ────────────────────────────────────────────
        Label formTitle = new Label("Registrar Nova Matrícula");
        formTitle.setStyle("-fx-text-fill: " + UIHelper.COLOR_TEXT + "; -fx-font-size: 15px; -fx-font-weight: bold;");

        VBox formBox = new VBox(16);
        formBox.setPadding(new Insets(20));
        formBox.setMaxWidth(500);
        formBox.setStyle("-fx-background-color: " + UIHelper.COLOR_CARD + "; -fx-background-radius: 10;");

        // Nome do aluno
        Label nomeLabel = UIHelper.fieldLabel("Nome do Aluno");
        TextField nomeField = new TextField();
        nomeField.setPromptText("Nome completo do aluno");
        nomeField.setStyle(UIHelper.textFieldStyle());
        nomeField.setMaxWidth(Double.MAX_VALUE);

        // Seleção de plano
        Label planoLabel = UIHelper.fieldLabel("Plano");
        ComboBox<String> planoCombo = new ComboBox<>();
        planoCombo.getItems().addAll(
            Planos.MAIS_BARATO + " — R$ 59,99",
            Planos.NORMAL       + " — R$ 89,99",
            Planos.PLUS_ULTRA   + " — R$ 119,99"
        );
        planoCombo.setPromptText("Selecione o plano");
        planoCombo.setMaxWidth(Double.MAX_VALUE);
        planoCombo.setStyle(UIHelper.comboStyle());

        // Forma de pagamento
        Label pgtoLabel = UIHelper.fieldLabel("Forma de Pagamento");
        ComboBox<String> pgtoCombo = new ComboBox<>();
        pgtoCombo.getItems().addAll("Cartão de Crédito", "Cartão de Débito", "PIX", "Dinheiro", "Boleto");
        pgtoCombo.setPromptText("Forma de pagamento");
        pgtoCombo.setMaxWidth(Double.MAX_VALUE);
        pgtoCombo.setStyle(UIHelper.comboStyle());

        Label feedbackLbl = new Label("");

        Button btnVender = UIHelper.primaryButton("✅  Confirmar Matrícula");
        btnVender.setOnAction(e -> {
            String nome  = nomeField.getText().trim();
            String plano = planoCombo.getValue();

            if (nome.isEmpty() || plano == null || pgtoCombo.getValue() == null) {
                feedbackLbl.setStyle("-fx-text-fill: " + UIHelper.COLOR_PRIMARY + "; -fx-font-size: 13px;");
                feedbackLbl.setText("⚠️ Preencha todos os campos.");
                return;
            }

            // Extrai o nome do plano (antes do " — ")
            String nomePlano = plano.split(" — ")[0];
            academia.registrarVendaPlano(nomePlano);

            // Atualiza contadores na tela
            cntBarato.setText(String.valueOf(academia.getTotalPlanoBarato()));
            cntNormal.setText(String.valueOf(academia.getTotalPlanoNormal()));
            cntPlus.setText(String.valueOf(academia.getTotalPlanoCaro()));

            feedbackLbl.setStyle("-fx-text-fill: " + UIHelper.COLOR_SUCCESS + "; -fx-font-size: 13px;");
            feedbackLbl.setText("🎉 Matrícula de " + nome + " no plano "" + nomePlano + "" registrada!");

            nomeField.clear();
            planoCombo.setValue(null);
            pgtoCombo.setValue(null);
        });

        formBox.getChildren().addAll(nomeLabel, nomeField, planoLabel, planoCombo,
                                     pgtoLabel, pgtoCombo, btnVender, feedbackLbl);

        wrapper.getChildren().addAll(currentTitle, counters, formTitle, formBox);
        return wrapper;
    }

    private VBox counterCard(String title, Label counter, String color) {
        VBox box = new VBox(6);
        box.setPadding(new Insets(18, 30, 18, 30));
        box.setAlignment(Pos.CENTER);
        box.setStyle(
            "-fx-background-color: " + UIHelper.COLOR_CARD + ";" +
            "-fx-background-radius: 10;" +
            "-fx-border-color: " + color + ";" +
            "-fx-border-width: 2;" +
            "-fx-border-radius: 10;"
        );
        Label t = new Label(title);
        t.setStyle("-fx-text-fill: " + color + "; -fx-font-size: 13px; -fx-font-weight: bold;");
        box.getChildren().addAll(t, counter);
        return box;
    }

    private Label counterLabel(String value) {
        Label l = new Label(value);
        l.setStyle("-fx-text-fill: " + UIHelper.COLOR_TEXT + "; -fx-font-size: 36px; -fx-font-weight: bold;");
        return l;
    }
}
