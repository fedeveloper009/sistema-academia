module com.academia {
    requires javafx.controls;
    requires javafx.fxml;

    opens com.academia to javafx.fxml;
    opens com.academia.controller to javafx.fxml;
    opens com.academia.model to javafx.fxml;

    exports com.academia;
    exports com.academia.controller;
    exports com.academia.model;
}
